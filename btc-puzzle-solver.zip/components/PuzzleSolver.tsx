"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import ranges from "@/lib/ranges"
import wallets from "@/lib/wallets"

export default function PuzzleSolver() {
  const [selectedRange, setSelectedRange] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [foundKey, setFoundKey] = useState("")
  const { toast } = useToast()

  const handleStart = async () => {
    if (!selectedRange) {
      toast({
        title: "Error",
        description: "Please select a puzzle range",
        variant: "destructive",
      })
      return
    }

    setIsRunning(true)
    setProgress(0)
    setFoundKey("")

    const range = ranges[Number.parseInt(selectedRange) - 1]
    const min = BigInt(range.min)
    const max = BigInt(range.max)
    const totalKeys = max - min

    for (let i = min; i <= max; i++) {
      const key = i.toString(16).padStart(64, "0")
      const address = await generatePublicAddress(key)

      if (wallets.includes(address)) {
        setFoundKey(key)
        toast({
          title: "Success",
          description: `Found matching key: ${key}`,
        })
        break
      }

      if (i % BigInt(1000) === BigInt(0)) {
        const progress = Number(((i - min) * BigInt(100)) / totalKeys)
        setProgress(progress)
      }

      // Allow UI to update
      await new Promise((resolve) => setTimeout(resolve, 0))
    }

    setIsRunning(false)
  }

  return (
    <div className="w-full max-w-md space-y-4">
      <div className="space-y-2">
        <Label htmlFor="puzzle-range">Select Puzzle Range</Label>
        <Select value={selectedRange} onValueChange={setSelectedRange}>
          <SelectTrigger id="puzzle-range">
            <SelectValue placeholder="Select a range" />
          </SelectTrigger>
          <SelectContent>
            {ranges.map((_, index) => (
              <SelectItem key={index} value={(index + 1).toString()}>
                Puzzle {index + 1}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button onClick={handleStart} disabled={isRunning}>
        {isRunning ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Running...
          </>
        ) : (
          "Start Puzzle Solver"
        )}
      </Button>
      {isRunning && (
        <div className="space-y-2">
          <Label>Progress</Label>
          <progress value={progress} max="100" className="w-full" />
          <p className="text-sm text-gray-500">{progress.toFixed(2)}% complete</p>
        </div>
      )}
      {foundKey && (
        <div className="space-y-2">
          <Label htmlFor="found-key">Found Key</Label>
          <Input id="found-key" value={foundKey} readOnly />
        </div>
      )}
    </div>
  )
}

async function generatePublicAddress(privateKey: string): Promise<string> {
  // This is a placeholder function. In a real implementation, you would use
  // a library like bitcoinjs-lib to generate the public address from the private key.
  // For demonstration purposes, we're just returning a random address from the wallets list.
  return wallets[Math.floor(Math.random() * wallets.length)]
}

